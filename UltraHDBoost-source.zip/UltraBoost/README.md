# UltraBoost — Android Source Project

This is a **Gradle source project**, not an APK. Build it via Android Studio
or your existing GitHub Actions CI/CD (same as PremiumSounds/BattleGrid).

## ⚠️ Two things YOU must still add before this builds/runs fully

1. **Gradle wrapper jar is missing.**
   I don't have network access in this environment, so I couldn't download
   `gradle/wrapper/gradle-wrapper.jar`. `gradle-wrapper.properties` is
   already in place (points to Gradle 8.4). Fix with ONE of:
   - Open the project folder in Android Studio — it will auto-generate the
     wrapper jar on first sync, **or**
   - On any machine with Gradle installed: `gradle wrapper` inside the
     project root, **or**
   - If your GitHub Actions workflow uses `gradle/actions/setup-gradle`
     instead of `./gradlew`, you may not need the wrapper jar at all.

2. **The AI upscale model file is missing.**
   `FrameProcessor` expects `app/src/main/assets/fsrcnn-x3.tflite`
   (a lightweight FSRCNN/ESPCN-style model, ~3x scale). I can't generate a
   trained model file. You'll need to convert one (e.g. from a public
   FSRCNN/ESPCN TensorFlow checkpoint) to `.tflite` and drop it in `assets/`.
   **The app will not crash without it** — `FrameProcessor` falls back to
   plain bitmap scaling automatically — but you won't get real AI upscaling
   until the model is added.

## What I fixed from the files you sent

- `MainActivity.kt` — missing `clickable` import.
- `ScreenCaptureService.kt` — missing `Activity` import; added
  `MediaProjection.registerCallback()` (required on Android 14+ or
  `createVirtualDisplay` throws); now publishes the MediaProjection token to
  `AppSettings` so other services can reuse it instead of each requesting
  their own.
- `AudioEnhancer.kt` — replaced `REMOTE_SUBMIX` (system-only, won't work in
  a normal installed app) with `AudioPlaybackCaptureConfiguration` using the
  same MediaProjection token from screen capture; fixed an output-buffer
  size mismatch (was sizing for stereo input but writing multi-channel
  arrays into a stereo `AudioTrack`, which would underrun/garble audio);
  fixed a `Short`/`Int` `coerceIn` type bug in `setBassBoost`.
- `floating_control_panel.xml` — `ImageButton` doesn't render `android:text`
  (it extends `ImageView`); FLAT/BASS/MOVIE preset labels now use separate
  `TextView`s underneath each button instead.
- `FloatingWindowService.kt` — was about to create a **second** `AudioRecord`
  on the same playback-capture config (would conflict with the one in
  `AudioEnhancerService`). Now it controls the single shared instance via
  `AudioEnhancerService.activeAudioEnhancer` instead.
- `FrameProcessor.kt` — rewritten for a realistic real-time target: swapped
  the (too-heavy-for-mobile-real-time) RealESRGAN-x4 pipeline for a
  lightweight ~3x model + frame-skipping, with a safe non-AI fallback if the
  model file is missing or inference fails.
- `AndroidManifest.xml` — removed `PROJECT_MEDIA` and
  `CAPTURE_VIDEO_OUTPUT`, which are signature-level system permissions a
  normal app can't hold (harmless to leave, but meaningless); added
  `POST_NOTIFICATIONS` (required on API 33+ for your foreground-service
  notifications to actually show).
- `app/build.gradle` — removed `be.tarsos.dsp:core:2.5`, which isn't used
  anywhere in the code and isn't reliably resolvable from Maven Central
  (would likely break the build with a dependency-resolution error).

## Files I wrote from scratch (were referenced but never sent)

`UltraBoostApp.kt`, `AudioEnhancerService.kt`, `VideoEnhancerService.kt`,
`UniversalDetectorService.kt`, `BootReceiver.kt`, Compose theme
(`Color.kt`/`Type.kt`/`Theme.kt`), `strings.xml`, `colors.xml`,
`themes.xml`, all drawables (currently simple placeholder shapes/vectors —
swap for real icon art), adaptive launcher icon, `AppSettings.kt` (shared
state object so the 3 foreground services coordinate instead of each
duplicating the capture pipeline), `settings.gradle`, root `build.gradle`,
`gradle.properties`, `proguard-rules.pro`.

## Honest product notes (please read before marketing copy)

- **"Real 5.1 / Dolby Atmos" isn't accurate marketing language.** A stereo
  source (YouTube, Instagram, etc.) doesn't contain real discrete
  surround-channel data — it can't be recovered, only approximated via
  gain-shaping/reverb/HRTF tricks. The code/UI now says "simulated" /
  "immersive" rather than claiming real Atmos — also worth noting Dolby is
  a licensed trademark.
- **2K/4K real-time upscale isn't realistic on mobile** with any model
  light enough to run at 30fps. UI now only enables 720p/1080p; 2K/4K are
  shown disabled rather than promising something undeliverable.
- **Enhanced video currently has no render target.** `ScreenCaptureService`
  captures → upscales → enhances a bitmap, but where that bitmap actually
  gets displayed back to the user (a fullscreen overlay `SurfaceView`?
  picture-in-picture?) was never specified, so I left it as a clearly
  marked `TODO` rather than guessing at a UX I might get wrong. This is the
  main remaining integration piece.
- **Accessibility Service disclosure**: Play Store requires a clear
  in-app explanation of why you need accessibility access, shown before
  the user grants it, or the app risks rejection at review.
