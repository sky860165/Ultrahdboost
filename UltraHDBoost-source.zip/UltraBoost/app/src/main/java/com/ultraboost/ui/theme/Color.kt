package com.ultraboost.ui.theme

import androidx.compose.ui.graphics.Color

val UltraBoostCyan = Color(0xFF00D4FF)
val UltraBoostGold = Color(0xFFFFD700)
val UltraBoostBgDark = Color(0xFF0F0F23)
val UltraBoostBgMid = Color(0xFF1A1A3E)
val UltraBoostCard = Color(0xFF1E1E3F)
val UltraBoostError = Color(0xFFFF4444)
val UltraBoostSuccess = Color(0xFF00FF88)
