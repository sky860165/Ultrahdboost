package com.ultraboost.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.ultraboost.MainActivity
import com.ultraboost.R
import com.ultraboost.audio.AudioEnhancer
import com.ultraboost.settings.AppSettings

/**
 * Foreground service that owns the AudioEnhancer instance and reacts to
 * mode/EQ changes made elsewhere (e.g. FloatingWindowService) via AppSettings.
 * Reuses the MediaProjection already obtained by ScreenCaptureService
 * (AppSettings.activeMediaProjection) instead of requesting a second one.
 */
class AudioEnhancerService : Service() {

    companion object {
        const val NOTIFICATION_ID = 2

        // Single source of truth for the live AudioEnhancer instance, so
        // FloatingWindowService (and anything else) controls THIS instance
        // instead of spinning up a second AudioRecord on the same capture
        // config, which would conflict with this one.
        @Volatile
        var activeAudioEnhancer: AudioEnhancer? = null
            private set
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, createNotification())

        if (activeAudioEnhancer == null) {
            val enhancer = AudioEnhancer()
            val ok = enhancer.initialize(AppSettings.activeMediaProjection)
            if (ok) {
                enhancer.startProcessing()
                activeAudioEnhancer = enhancer
            } else {
                // Init failed (e.g. no MediaProjection yet, or device unsupported) —
                // stop quietly rather than crash the foreground service.
                stopSelf()
            }
        }

        return START_STICKY
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, ScreenCaptureService.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Ultra HD Boost Audio")
            .setContentText("Enhancing audio in real-time")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        activeAudioEnhancer?.release()
        activeAudioEnhancer = null
    }
}
