package com.ultraboost.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.ultraboost.MainActivity
import com.ultraboost.R
import com.ultraboost.settings.AppSettings

/**
 * NOTE: The actual frame capture + AI upscale loop lives in
 * ScreenCaptureService + FrameProcessor — duplicating that pipeline here
 * would mean two competing MediaProjection/VirtualDisplay consumers.
 * This service's job is narrower: it's the foreground-service holder for
 * "video enhancement is active" status and applies quality-target changes
 * (e.g. user picks 1080p vs 720p in the floating panel) to AppSettings,
 * which ScreenCaptureService/FrameProcessor read from.
 */
class VideoEnhancerService : Service() {

    companion object {
        const val NOTIFICATION_ID = 3
        const val EXTRA_QUALITY = "extra_quality"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.getStringExtra(EXTRA_QUALITY)?.let { quality ->
            AppSettings.targetQuality = quality
        }
        startForeground(NOTIFICATION_ID, createNotification())
        return START_STICKY
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, ScreenCaptureService.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Ultra HD Boost Video")
            .setContentText("Target quality: ${AppSettings.targetQuality}")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
