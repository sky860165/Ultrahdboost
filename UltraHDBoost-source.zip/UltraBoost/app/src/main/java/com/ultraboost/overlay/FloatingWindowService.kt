package com.ultraboost.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.ultraboost.R
import com.ultraboost.audio.AudioEnhancer
import com.ultraboost.audio.EQPresets
import com.ultraboost.service.AudioEnhancerService
import com.ultraboost.settings.AppSettings

class FloatingWindowService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private var params: WindowManager.LayoutParams? = null

    // NOT a separate AudioEnhancer instance — controls the one already
    // running inside AudioEnhancerService, to avoid two AudioRecord
    // instances fighting over the same playback-capture config.
    private val audioEnhancer: AudioEnhancer?
        get() = AudioEnhancerService.activeAudioEnhancer

    private var isExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createFloatingWindow()
    }

    private fun createFloatingWindow() {
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_control_panel, null)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
        }

        setupFloatingView()
        windowManager.addView(floatingView, params)
    }

    private fun setupFloatingView() {
        floatingView?.let { view ->
            val mainButton = view.findViewById<ImageButton>(R.id.btn_main)
            val controlPanel = view.findViewById<LinearLayout>(R.id.control_panel)

            var initialX = 0
            var initialY = 0
            var touchX = 0f
            var touchY = 0f

            mainButton.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params!!.x
                        initialY = params!!.y
                        touchX = event.rawX
                        touchY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params!!.x = initialX + (event.rawX - touchX).toInt()
                        params!!.y = initialY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(floatingView, params)
                        true
                    }
                    else -> false
                }
            }

            mainButton.setOnClickListener {
                isExpanded = !isExpanded
                controlPanel.visibility = if (isExpanded) View.VISIBLE else View.GONE
            }

            setupEQControls(view)
            setupModeSelector(view)
            setupQualitySelector(view)
        }
    }

    private fun setupEQControls(view: View) {
        val eqBars = listOf(
            R.id.eq_60hz to 0,
            R.id.eq_170hz to 1,
            R.id.eq_310hz to 2,
            R.id.eq_600hz to 3,
            R.id.eq_1khz to 4,
            R.id.eq_3khz to 5,
            R.id.eq_6khz to 6,
            R.id.eq_12khz to 7,
            R.id.eq_14khz to 8,
            R.id.eq_16khz to 9
        )

        eqBars.forEach { (seekBarId, bandIndex) ->
            val seekBar = view.findViewById<SeekBar>(seekBarId)
            seekBar?.max = 30
            seekBar?.progress = 15

            seekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val db = (progress - 15).toFloat()
                    audioEnhancer?.setEqualizerBand(bandIndex, db)
                    view.findViewById<TextView>(R.id.tv_eq_value)?.text = "${db.toInt()}dB"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        view.findViewById<ImageButton>(R.id.btn_preset_flat)?.setOnClickListener {
            applyPreset(EQPresets.FLAT, view)
        }
        view.findViewById<ImageButton>(R.id.btn_preset_bass)?.setOnClickListener {
            applyPreset(EQPresets.BASS_BOOST, view)
        }
        view.findViewById<ImageButton>(R.id.btn_preset_movie)?.setOnClickListener {
            applyPreset(EQPresets.MOVIE, view)
        }
    }

    private fun applyPreset(preset: FloatArray, view: View) {
        val eqBars = listOf(
            R.id.eq_60hz, R.id.eq_170hz, R.id.eq_310hz,
            R.id.eq_600hz, R.id.eq_1khz, R.id.eq_3khz,
            R.id.eq_6khz, R.id.eq_12khz, R.id.eq_14khz, R.id.eq_16khz
        )

        preset.forEachIndexed { index, value ->
            val seekBar = view.findViewById<SeekBar>(eqBars[index])
            seekBar?.progress = (value + 15).toInt()
            audioEnhancer?.setEqualizerBand(index, value)
        }
    }

    private fun setupModeSelector(view: View) {
        view.findViewById<ImageButton>(R.id.btn_mode_stereo)?.setOnClickListener {
            audioEnhancer?.setAudioMode(AudioEnhancer.AudioMode.STEREO)
            AppSettings.audioMode = "STEREO"
            updateModeIndicator(view, "STEREO")
        }
        view.findViewById<ImageButton>(R.id.btn_mode_surround)?.setOnClickListener {
            audioEnhancer?.setAudioMode(AudioEnhancer.AudioMode.SURROUND_51)
            AppSettings.audioMode = "SURROUND_51"
            updateModeIndicator(view, "5.1 SURROUND")
        }
        view.findViewById<ImageButton>(R.id.btn_mode_atmos)?.setOnClickListener {
            audioEnhancer?.setAudioMode(AudioEnhancer.AudioMode.DOLBY_ATMOS_512)
            AppSettings.audioMode = "DOLBY_ATMOS_512"
            updateModeIndicator(view, "5.1.2 IMMERSIVE")
        }
        view.findViewById<ImageButton>(R.id.btn_mode_3d)?.setOnClickListener {
            audioEnhancer?.setAudioMode(AudioEnhancer.AudioMode.SPATIAL_3D)
            AppSettings.audioMode = "SPATIAL_3D"
            updateModeIndicator(view, "3D SPATIAL")
        }
    }

    private fun setupQualitySelector(view: View) {
        val qualityButtons = mapOf(
            R.id.btn_quality_720 to "720p",
            R.id.btn_quality_1080 to "1080p",
            R.id.btn_quality_2k to "2K",
            R.id.btn_quality_4k to "4K"
        )

        qualityButtons.forEach { (id, quality) ->
            view.findViewById<ImageButton>(id)?.setOnClickListener {
                AppSettings.targetQuality = quality
                updateQualityIndicator(view, quality)
            }
        }
    }

    private fun updateModeIndicator(view: View, mode: String) {
        view.findViewById<TextView>(R.id.tv_current_mode)?.text = mode
    }

    private fun updateQualityIndicator(view: View, quality: String) {
        view.findViewById<TextView>(R.id.tv_current_quality)?.text = quality
    }

    override fun onDestroy() {
        super.onDestroy()
        // audioEnhancer is owned by AudioEnhancerService — not released here.
        if (floatingView != null) {
            windowManager.removeView(floatingView)
        }
    }
}
