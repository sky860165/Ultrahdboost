package com.ultraboost.audio

import android.content.Context

/**
 * 10 built-in equalizer presets (10-band, gains in dB, range -15..+15 to
 * match AudioEnhancer.equalizerBands) + a user-editable "Custom" preset
 * persisted to SharedPreferences so it survives app restarts.
 *
 * Bands (Hz, approximate center frequencies for a typical 10-band EQ):
 * 31 / 62 / 125 / 250 / 500 / 1k / 2k / 4k / 8k / 16k
 */
data class EqPreset(
    val name: String,
    val bands: FloatArray
)

object EqualizerPresets {

    const val BAND_COUNT = 10
    val bandLabels = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

    private const val PREFS_NAME = "ultraboost_eq_prefs"
    private const val CUSTOM_KEY = "custom_bands"

    val builtIn: List<EqPreset> = listOf(
        EqPreset("Flat", FloatArray(BAND_COUNT) { 0f }),
        EqPreset("Bass Boost", floatArrayOf(8f, 7f, 6f, 4f, 1f, 0f, 0f, 0f, 0f, 0f)),
        EqPreset("Treble Boost", floatArrayOf(0f, 0f, 0f, 0f, 0f, 1f, 4f, 6f, 7f, 8f)),
        EqPreset("Vocal Boost", floatArrayOf(-2f, -2f, -1f, 2f, 5f, 5f, 3f, 0f, -1f, -1f)),
        EqPreset("Rock", floatArrayOf(5f, 4f, 3f, 0f, -2f, -1f, 1f, 3f, 4f, 5f)),
        EqPreset("Pop", floatArrayOf(-1f, 0f, 2f, 4f, 4f, 3f, 1f, 0f, -1f, -1f)),
        EqPreset("Jazz", floatArrayOf(3f, 2f, 1f, 2f, -1f, -1f, 0f, 2f, 3f, 4f)),
        EqPreset("Classical", floatArrayOf(4f, 3f, 2f, 1f, -1f, -1f, 0f, 2f, 3f, 4f)),
        EqPreset("Dance", floatArrayOf(7f, 6f, 3f, 0f, -1f, 2f, 4f, 4f, 3f, 2f)),
        EqPreset("Movie / Cinema", floatArrayOf(4f, 4f, 2f, 1f, 0f, 1f, 2f, 3f, 4f, 5f))
    )

    fun loadCustom(context: Context): EqPreset {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(CUSTOM_KEY, null)
        val bands = if (saved != null) {
            try {
                saved.split(",").map { it.toFloat() }.toFloatArray()
                    .let { if (it.size == BAND_COUNT) it else FloatArray(BAND_COUNT) { 0f } }
            } catch (e: Exception) {
                FloatArray(BAND_COUNT) { 0f }
            }
        } else {
            FloatArray(BAND_COUNT) { 0f }
        }
        return EqPreset("Custom", bands)
    }

    fun saveCustom(context: Context, bands: FloatArray) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(CUSTOM_KEY, bands.joinToString(",")).apply()
    }

    /** All presets including the persisted Custom one, in display order. */
    fun all(context: Context): List<EqPreset> = builtIn + loadCustom(context)
}
