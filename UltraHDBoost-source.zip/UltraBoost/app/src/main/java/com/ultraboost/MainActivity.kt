package com.ultraboost

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.ultraboost.overlay.FloatingWindowService
import com.ultraboost.service.AudioEnhancerService
import com.ultraboost.service.ScreenCaptureService
import com.ultraboost.service.VideoEnhancerService
import com.ultraboost.settings.AppSettings
import com.ultraboost.ui.theme.UltraBoostTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

class MainActivity : ComponentActivity() {

    private val mediaProjectionManager by lazy {
        getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val intent = result.data
            startEnhancerService(intent)
            Toast.makeText(this, "Ultra HD Boost Activated! \uD83D\uDE80", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UltraBoostTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(
                        onStartEnhancer = { requestScreenCapture() },
                        onStopEnhancer = { stopEnhancerService() },
                        onOpenSettings = { openFloatingWindowSettings() },
                        onOpenEqualizer = { startActivity(Intent(this, EqualizerActivity::class.java)) }
                    )
                }
            }
        }
    }

    private fun requestScreenCapture() {
        val captureIntent = mediaProjectionManager.createScreenCaptureIntent()
        screenCaptureLauncher.launch(captureIntent)
    }

    private fun startEnhancerService(data: Intent?) {
        // ScreenCaptureService owns the MediaProjection and publishes it to
        // AppSettings; AudioEnhancerService/VideoEnhancerService are started
        // right after so they can read it (see ScreenCaptureService).
        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun stopEnhancerService() {
        // Stopping ScreenCaptureService releases the MediaProjection in
        // onDestroy(), which also stops AudioEnhancerService/VideoEnhancerService
        // (they read the same token and have nothing left to do once it's gone).
        stopService(Intent(this, ScreenCaptureService::class.java))
        stopService(Intent(this, AudioEnhancerService::class.java))
        stopService(Intent(this, VideoEnhancerService::class.java))
        AppSettings.clear()
        Toast.makeText(this, "Ultra HD Boost stopped", Toast.LENGTH_SHORT).show()
    }

    private fun openFloatingWindowSettings() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            startService(Intent(this, FloatingWindowService::class.java))
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun MainScreen(
    onStartEnhancer: () -> Unit,
    onStopEnhancer: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenEqualizer: () -> Unit
) {
    val context = LocalContext.current
    val isEnhancerActive by AppSettings.isEnhancerRunningFlow.collectAsState(initial = AppSettings.isEnhancerRunning)
    var selectedQuality by remember { mutableStateOf("1080p") }
    var selectedAudio by remember { mutableStateOf("Stereo") }

    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(
            android.Manifest.permission.RECORD_AUDIO
        )
    )

    LaunchedEffect(Unit) {
        permissionsState.launchMultiplePermissionRequest()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F0F23),
                        Color(0xFF1A1A3E),
                        Color(0xFF0F0F23)
                    )
                )
            )
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(40.dp))

        Text(
            text = "\u26A1 ULTRA HD BOOST",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00D4FF)
        )

        Text(
            text = "AI Video Upscaler & Audio Enhancer",
            fontSize = 14.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(40.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1E1E3F)
            )
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isEnhancerActive) "\uD83D\uDFE2 ACTIVE" else "\uD83D\uDD34 INACTIVE",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isEnhancerActive) Color(0xFF00FF88) else Color(0xFFFF4444)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Video Quality",
                    fontSize = 14.sp,
                    color = Color.Gray
                )

                // Note: 2K/4K are NOT real-time achievable on mobile with this
                // pipeline (see FrameProcessor notes) — only 720p/1080p are
                // wired to a real model path; 2K/4K are kept here as
                // disabled/future options rather than promising something
                // the app can't currently deliver.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("720p", "1080p", "2K", "4K").forEach { quality ->
                        val enabled = quality == "720p" || quality == "1080p"
                        QualityChip(
                            text = quality,
                            selected = selectedQuality == quality,
                            enabled = enabled,
                            onClick = {
                                selectedQuality = quality
                                AppSettings.targetQuality = quality
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Audio Enhancement",
                    fontSize = 14.sp,
                    color = Color.Gray
                )

                Column(modifier = Modifier.padding(vertical = 8.dp)) {
                    AudioOption(
                        text = "\uD83C\uDFB5 Stereo + EQ",
                        selected = selectedAudio == "Stereo",
                        onClick = { selectedAudio = "Stereo"; AppSettings.audioMode = "STEREO" }
                    )
                    AudioOption(
                        text = "\uD83D\uDD0A 5.1 Surround (simulated)",
                        selected = selectedAudio == "5.1",
                        onClick = { selectedAudio = "5.1"; AppSettings.audioMode = "SURROUND_51" }
                    )
                    AudioOption(
                        text = "\uD83C\uDFA7 5.1.2 Immersive (simulated)",
                        selected = selectedAudio == "Atmos",
                        onClick = { selectedAudio = "Atmos"; AppSettings.audioMode = "DOLBY_ATMOS_512" }
                    )
                    AudioOption(
                        text = "\uD83C\uDF10 3D Spatial Audio",
                        selected = selectedAudio == "3D",
                        onClick = { selectedAudio = "3D"; AppSettings.audioMode = "SPATIAL_3D" }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (isEnhancerActive) {
                    onStopEnhancer()
                } else {
                    onStartEnhancer()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isEnhancerActive) Color(0xFFFF4444) else Color(0xFF00D4FF)
            )
        ) {
            Text(
                text = if (isEnhancerActive) "STOP ENHANCER" else "ACTIVATE ULTRABOOST",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = onOpenSettings,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = Color(0xFF00D4FF)
            )
        ) {
            Text("\uD83C\uDF9B\uFE0F Open Control Panel")
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onOpenEqualizer,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = Color(0xFF00D4FF)
            )
        ) {
            Text("\uD83C\uDF9A\uFE0F Equalizer & Sound Effects")
        }

        Spacer(modifier = Modifier.weight(1f))
    }
}

@Composable
fun QualityChip(
    text: String,
    selected: Boolean,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                when {
                    !enabled -> Color.DarkGray.copy(alpha = 0.5f)
                    selected -> Color(0xFF00D4FF)
                    else -> Color(0xFF2A2A5A)
                }
            )
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = text,
            color = when {
                !enabled -> Color.Gray
                selected -> Color.Black
                else -> Color.White
            },
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
fun AudioOption(
    text: String,
    selected: Boolean,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected) Color(0xFF00D4FF).copy(alpha = 0.2f) else Color.Transparent
            )
            .clickable(enabled = enabled) { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = null,
            enabled = enabled,
            colors = RadioButtonDefaults.colors(
                selectedColor = Color(0xFF00D4FF),
                unselectedColor = Color.Gray
            )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            color = if (enabled) Color.White else Color.Gray,
            fontSize = 14.sp
        )
        if (!enabled) {
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "\uD83D\uDC51",
                fontSize = 14.sp
            )
        }
    }
}
