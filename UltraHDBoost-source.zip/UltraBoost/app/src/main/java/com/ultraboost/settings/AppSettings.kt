package com.ultraboost.settings

import android.media.projection.MediaProjection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Process-wide shared state. Avoids duplicating capture pipelines across
 * ScreenCaptureService / AudioEnhancerService / VideoEnhancerService —
 * they all read/write this single source of truth instead of each
 * re-deriving a MediaProjection or duplicating quality/mode state.
 */
object AppSettings {

    @Volatile
    var activeMediaProjection: MediaProjection? = null

    @Volatile
    var targetQuality: String = "720p" // "720p" | "1080p" (2K/4K not realistic in real-time, see notes)

    @Volatile
    var audioMode: String = "STEREO" // STEREO | SURROUND_51 | DOLBY_ATMOS_512 | SPATIAL_3D

    // StateFlow instead of a plain var so the UI (MainActivity) can collect
    // live updates and stay in sync with the actual service state — fixes
    // the bug where the UI showed "INACTIVE" after backgrounding/reopening
    // the app even though the foreground service was still running.
    private val _isEnhancerRunning = MutableStateFlow(false)
    val isEnhancerRunningFlow: StateFlow<Boolean> = _isEnhancerRunning

    var isEnhancerRunning: Boolean
        get() = _isEnhancerRunning.value
        set(value) { _isEnhancerRunning.value = value }

    fun clear() {
        activeMediaProjection = null
        isEnhancerRunning = false
    }
}
