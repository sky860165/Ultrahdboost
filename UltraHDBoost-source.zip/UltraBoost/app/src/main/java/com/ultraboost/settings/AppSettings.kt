package com.ultraboost.settings

import android.media.projection.MediaProjection

/**
 * Process-wide shared state. Avoids duplicating capture pipelines across
 * ScreenCaptureService / AudioEnhancerService / VideoEnhancerService —
 * they all read/write this single source of truth instead of each
 * re-deriving a MediaProjection or duplicating quality/mode state.
 */
object AppSettings {

    @Volatile
    var activeMediaProjection: MediaProjection? = null

    @Volatile
    var targetQuality: String = "720p" // "720p" | "1080p" (2K/4K not realistic in real-time, see notes)

    @Volatile
    var audioMode: String = "STEREO" // STEREO | SURROUND_51 | DOLBY_ATMOS_512 | SPATIAL_3D

    @Volatile
    var isEnhancerRunning: Boolean = false

    fun clear() {
        activeMediaProjection = null
        isEnhancerRunning = false
    }
}
