package com.ultraboost.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.support.common.FileUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer

/**
 * Lightweight real-time upscaler.
 * Target: source (144p-480p) -> up to 1080p, NOT 4K.
 * Uses a small model (e.g. FSRCNN / ESPCN-style, ~3x scale) instead of
 * RealESRGAN, which is too heavy for real-time mobile inference.
 *
 * Model expectations:
 *  - File: assets/fsrcnn-x3.tflite  (swap in your converted model)
 *  - Input: [1, H, W, 3] float32, normalized 0-1
 *  - Output: [1, H*scaleFactor, W*scaleFactor, 3] float32, 0-1
 *  - Dynamic input size (no fixed 256x256) so we can feed variable capture sizes.
 *    If your model requires a fixed input shape, set FIXED_INPUT = true below
 *    and adjust inputW/inputH to match the model.
 */
class FrameProcessor(
    private val context: Context,
    private val captureWidth: Int,
    private val captureHeight: Int
) {
    companion object {
        private const val TAG = "FrameProcessor"
        private const val MODEL_FILE = "fsrcnn-x3.tflite"
        const val SCALE_FACTOR = 3 // e.g. 360x640 -> 1080x1920

        // Set true only if your .tflite model has a fixed input shape.
        private const val FIXED_INPUT = false
        private const val FIXED_W = 320
        private const val FIXED_H = 180
    }

    private var interpreter: Interpreter? = null
    private var frameCounter = 0

    // Process every Nth frame; reuse last result for skipped frames.
    // 2 = process every other frame (~halves inference load).
    var frameSkip = 2

    private var lastOutput: Bitmap? = null

    private val modelInputW: Int
    private val modelInputH: Int

    init {
        modelInputW = if (FIXED_INPUT) FIXED_W else captureWidth
        modelInputH = if (FIXED_INPUT) FIXED_H else captureHeight

        try {
            val model = loadModel(context, MODEL_FILE)
            interpreter = createInterpreter(model)
        } catch (e: Exception) {
            Log.e(TAG, "Model load failed, falling back to non-AI upscale: ${e.message}")
            interpreter = null
        }
    }

    private fun loadModel(context: Context, modelName: String): MappedByteBuffer {
        return FileUtil.loadMappedFile(context, modelName)
    }

    private fun createInterpreter(model: MappedByteBuffer): Interpreter {
        val compatList = CompatibilityList()
        val options = Interpreter.Options().apply {
            if (compatList.isDelegateSupportedOnThisDevice) {
                addDelegate(GpuDelegate())
            } else {
                setNumThreads(4)
            }
            setUseXNNPACK(true)
        }
        return Interpreter(model, options)
    }

    /**
     * Returns an upscaled bitmap. On skipped frames returns the last
     * successful result (cheap) instead of re-running inference.
     */
    suspend fun upscaleFrame(bitmap: Bitmap): Bitmap = withContext(Dispatchers.Default) {
        frameCounter++

        val shouldRunInference = interpreter != null && (frameCounter % frameSkip == 0)

        if (!shouldRunInference) {
            return@withContext lastOutput ?: fallbackUpscale(bitmap)
        }

        try {
            val outW = modelInputW * SCALE_FACTOR
            val outH = modelInputH * SCALE_FACTOR

            val inputBuffer = bitmapToInputBuffer(bitmap, modelInputW, modelInputH)
            val outputBuffer = ByteBuffer
                .allocateDirect(4 * outW * outH * 3)
                .order(ByteOrder.nativeOrder())

            interpreter?.run(inputBuffer, outputBuffer)

            val result = outputBufferToBitmap(outputBuffer, outW, outH)
            lastOutput?.recycle()
            lastOutput = result
            result
        } catch (e: Exception) {
            Log.e(TAG, "Inference failed, using fallback: ${e.message}")
            fallbackUpscale(bitmap)
        }
    }

    /** Non-AI fallback so the pipeline never breaks if the model is missing/fails. */
    private fun fallbackUpscale(bitmap: Bitmap): Bitmap {
        val outW = bitmap.width * SCALE_FACTOR
        val outH = bitmap.height * SCALE_FACTOR
        return Bitmap.createScaledBitmap(bitmap, outW, outH, true)
    }

    private fun bitmapToInputBuffer(bitmap: Bitmap, w: Int, h: Int): ByteBuffer {
        val scaled = if (bitmap.width != w || bitmap.height != h) {
            Bitmap.createScaledBitmap(bitmap, w, h, true)
        } else bitmap

        val buffer = ByteBuffer.allocateDirect(4 * w * h * 3).order(ByteOrder.nativeOrder())
        val pixels = IntArray(w * h)
        scaled.getPixels(pixels, 0, w, 0, 0, w, h)

        for (p in pixels) {
            buffer.putFloat(((p shr 16) and 0xFF) / 255f) // R
            buffer.putFloat(((p shr 8) and 0xFF) / 255f)  // G
            buffer.putFloat((p and 0xFF) / 255f)           // B
        }
        buffer.rewind()

        if (scaled !== bitmap) scaled.recycle()
        return buffer
    }

    private fun outputBufferToBitmap(buffer: ByteBuffer, w: Int, h: Int): Bitmap {
        buffer.rewind()
        val pixels = IntArray(w * h)
        for (i in 0 until w * h) {
            val r = (buffer.float * 255).toInt().coerceIn(0, 255)
            val g = (buffer.float * 255).toInt().coerceIn(0, 255)
            val b = (buffer.float * 255).toInt().coerceIn(0, 255)
            pixels[i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
        }
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap.setPixels(pixels, 0, w, 0, 0, w, h)
        return bitmap
    }

    fun applyEnhancements(bitmap: Bitmap): Bitmap {
        val sharpened = applySharpening(bitmap)
        return applyToneMapping(sharpened)
    }

    private fun applyToneMapping(bitmap: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        val canvas = Canvas(result)
        val colorMatrix = ColorMatrix().apply {
            setSaturation(1.1f)
        }
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }
        canvas.drawBitmap(bitmap, 0f, 0f, paint)
        return result
    }

    private fun applySharpening(bitmap: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        val canvas = Canvas(result)
        canvas.drawBitmap(bitmap, 0f, 0f, null)
        val paint = Paint().apply {
            alpha = 100
            xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.OVERLAY)
        }
        canvas.drawBitmap(bitmap, 0.5f, 0.5f, paint)
        return result
    }

    fun release() {
        interpreter?.close()
        lastOutput?.recycle()
        lastOutput = null
    }
}
