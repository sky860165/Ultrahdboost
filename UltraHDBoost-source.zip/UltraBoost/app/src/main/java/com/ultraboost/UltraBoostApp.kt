package com.ultraboost

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class UltraBoostApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            val channel = NotificationChannel(
                "ultraboost_channel",
                "Ultra HD Boost Enhancer",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Real-time video and audio enhancement status"
                setShowBadge(false)
            }

            manager.createNotificationChannel(channel)
        }
    }
}
