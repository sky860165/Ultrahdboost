package com.ultraboost.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Surface
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.ultraboost.MainActivity
import com.ultraboost.R
import com.ultraboost.ai.FrameProcessor
import com.ultraboost.settings.AppSettings
import kotlinx.coroutines.*

class ScreenCaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val NOTIFICATION_CHANNEL_ID = "ultraboost_channel"
        const val NOTIFICATION_ID = 1
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var frameProcessor: FrameProcessor? = null

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // System revoked/stopped the projection (e.g. user revoked from
            // the system status bar control). Clean up to avoid using a
            // dead projection on subsequent calls.
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(metrics)

        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        if (resultData != null) {
            startForeground(NOTIFICATION_ID, createNotification())
            initializeMediaProjection(resultData)
        }

        return START_STICKY
    }

    private fun initializeMediaProjection(resultData: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
            as MediaProjectionManager

        mediaProjection = projectionManager.getMediaProjection(Activity.RESULT_OK, resultData)
        // Required on Android 14+ before createVirtualDisplay / audio capture config,
        // otherwise the platform throws IllegalStateException.
        mediaProjection?.registerCallback(projectionCallback, mainHandler)

        // Publish so AudioEnhancerService / VideoEnhancerService can reuse the
        // SAME token instead of each requesting their own capture permission.
        AppSettings.activeMediaProjection = mediaProjection
        AppSettings.isEnhancerRunning = true

        // Half-resolution capture target feeds FrameProcessor, which upscales
        // toward AppSettings.targetQuality (720p/1080p — see FrameProcessor notes
        // on why 2K/4K aren't realistic in real-time on mobile).
        val captureWidth = (screenWidth / 2).coerceAtLeast(2)
        val captureHeight = (screenHeight / 2).coerceAtLeast(2)

        frameProcessor = FrameProcessor(this, captureWidth, captureHeight)

        setupImageReader(captureWidth, captureHeight)
        createVirtualDisplay(captureWidth, captureHeight)
        startFrameProcessing()

        // Start the audio + video-state companion services now that the
        // projection token exists in AppSettings.
        ContextCompat.startForegroundService(
            this, Intent(this, AudioEnhancerService::class.java)
        )
        ContextCompat.startForegroundService(
            this,
            Intent(this, VideoEnhancerService::class.java).apply {
                putExtra(VideoEnhancerService.EXTRA_QUALITY, AppSettings.targetQuality)
            }
        )
    }

    private fun setupImageReader(captureWidth: Int, captureHeight: Int) {
        imageReader = ImageReader.newInstance(
            captureWidth,
            captureHeight,
            PixelFormat.RGBA_8888,
            3 // triple buffering
        )
    }

    private fun createVirtualDisplay(captureWidth: Int, captureHeight: Int) {
        val surface: Surface = imageReader!!.surface

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "UltraBoostCapture",
            captureWidth,
            captureHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            surface,
            object : VirtualDisplay.Callback() {
                override fun onStopped() {
                    // Handle display stopped
                }
            },
            mainHandler
        )
    }

    private fun startFrameProcessing() {
        imageReader?.setOnImageAvailableListener({ reader ->
            var image: Image? = null
            try {
                image = reader.acquireLatestImage()
                if (image != null) {
                    processFrame(image)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                image?.close()
            }
        }, mainHandler)
    }

    private fun processFrame(image: Image) {
        serviceScope.launch {
            val bitmap = imageToBitmap(image)

            val upscaledBitmap = frameProcessor?.upscaleFrame(bitmap)

            val enhancedBitmap = upscaledBitmap?.let {
                frameProcessor?.applyEnhancements(it)
            }

            // TODO: Render enhancedBitmap to the overlay surface
            // (FloatingWindowService / a dedicated SurfaceView) — rendering
            // target wasn't specified, so this is left as the integration
            // point rather than guessed at.
            // enhancedBitmap?.let { renderToOverlay(it) }

            bitmap.recycle()
            if (upscaledBitmap !== enhancedBitmap) upscaledBitmap?.recycle()
            enhancedBitmap?.recycle()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return bitmap
    }

    private fun createNotificationChannel() {
        val channel = android.app.NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            "Ultra HD Boost Enhancer",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Real-time video and audio enhancement"
            setShowBadge(false)
        }

        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(channel)
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("\u26A1 Ultra HD Boost Active")
            .setContentText("Enhancing video & audio in real-time")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        virtualDisplay?.release()
        mediaProjection?.unregisterCallback(projectionCallback)
        mediaProjection?.stop()
        imageReader?.close()
        frameProcessor?.release()
        AppSettings.clear()
    }
}
