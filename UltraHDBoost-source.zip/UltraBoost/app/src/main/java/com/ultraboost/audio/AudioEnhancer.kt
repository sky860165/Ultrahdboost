package com.ultraboost.audio

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.audiofx.BassBoost
import android.media.audiofx.EnvironmentalReverb
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.media.projection.MediaProjection
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import kotlinx.coroutines.*
import kotlin.math.*

/**
 * IMPORTANT — honesty note for whoever reads this later:
 * "SURROUND_51" / "DOLBY_ATMOS_512" / "SPATIAL_3D" here are stereo-upmix
 * SIMULATIONS (gain shaping + reverb + simple HRTF-style delay), not real
 * discrete-channel decode. A stereo source from YouTube/Instagram/etc. does
 * not contain real 5.1/Atmos channel data, so it can't be recovered — only
 * approximated. Keep that distinction in any user-facing copy (avoid
 * claiming "real Dolby Atmos"; Dolby is also a licensed trademark).
 *
 * System-audio capture: REMOTE_SUBMIX requires system-level signing and will
 * NOT work in a normal installed app, so it's replaced here with
 * AudioPlaybackCaptureConfiguration (API 29+), which uses the same
 * MediaProjection token already obtained for screen capture.
 */
class AudioEnhancer {

    companion object {
        private const val TAG = "AudioEnhancer"
    }

    private val sampleRate = 48000
    private val channelConfigIn = AudioFormat.CHANNEL_IN_STEREO
    private val audioFormat = AudioFormat.ENCODING_PCM_FLOAT

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var equalizer: Equalizer? = null
    private var virtualizer: Virtualizer? = null
    private var bassBoost: BassBoost? = null
    private var reverb: EnvironmentalReverb? = null

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var processingJob: Job? = null
    private var isProcessing = false

    var currentMode: AudioMode = AudioMode.STEREO
    var equalizerBands = FloatArray(10) { 0f } // -15dB to +15dB

    enum class AudioMode {
        STEREO, SURROUND_51, DOLBY_ATMOS_512, SPATIAL_3D
    }

    /**
     * @param mediaProjection required on API 29+ to capture other apps' playback.
     *  Pass the SAME MediaProjection instance used for screen capture
     *  (see AppSettings.activeMediaProjection). On API < 29 this falls back
     *  to mic input only, since playback capture isn't available pre-Q.
     */
    @SuppressLint("MissingPermission")
    fun initialize(mediaProjection: MediaProjection?): Boolean {
        val inBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfigIn, audioFormat)
        if (inBufferSize <= 0) {
            Log.e(TAG, "Invalid input buffer size, device doesn't support this config")
            return false
        }
        val recordBufferSize = inBufferSize * 4

        audioRecord = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && mediaProjection != null) {
                buildPlaybackCaptureRecord(mediaProjection, recordBufferSize)
            } else {
                Log.w(TAG, "No MediaProjection / API < 29 — falling back to MIC input, not app playback")
                buildMicFallbackRecord(recordBufferSize)
            }
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord init failed: ${e.message}")
            return false
        }

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord failed to initialize")
            return false
        }

        // Output buffer sized for actual OUTPUT channel mask (stereo passthrough here;
        // the "surround" modes below expand channel COUNT in software, they don't
        // change the AudioTrack's physical output format).
        val outBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_STEREO,
            audioFormat
        ).coerceAtLeast(recordBufferSize)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(audioFormat)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(outBufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        setupEffects()
        return true
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    @SuppressLint("MissingPermission")
    private fun buildPlaybackCaptureRecord(projection: MediaProjection, bufferSize: Int): AudioRecord {
        val captureConfig = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(audioFormat)
            .setSampleRate(sampleRate)
            .setChannelMask(channelConfigIn)
            .build()

        return AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferSize)
            .setAudioPlaybackCaptureConfig(captureConfig)
            .build()
    }

    @SuppressLint("MissingPermission")
    private fun buildMicFallbackRecord(bufferSize: Int): AudioRecord {
        return AudioRecord(
            android.media.MediaRecorder.AudioSource.MIC,
            sampleRate,
            channelConfigIn,
            audioFormat,
            bufferSize
        )
    }

    private fun setupEffects() {
        val audioSessionId = audioTrack?.audioSessionId ?: return

        equalizer = Equalizer(0, audioSessionId).apply {
            enabled = true
            val bandCount = numberOfBands.toInt().coerceAtMost(equalizerBands.size)
            for (i in 0 until bandCount) {
                setBandLevel(i.toShort(), (equalizerBands[i] * 100).toInt().toShort())
            }
        }

        virtualizer = Virtualizer(0, audioSessionId).apply {
            enabled = true
            setStrength(1000)
        }

        bassBoost = BassBoost(0, audioSessionId).apply {
            enabled = true
            setStrength(600) // moderate default "low bass boost" per request, adjustable via setBassBoost()
        }

        reverb = EnvironmentalReverb(0, audioSessionId).apply {
            enabled = false // only enabled for surround/atmos/3D modes, see setAudioMode()
            roomLevel = -900
            roomHFLevel = -100
            decayTime = 2000
            decayHFRatio = 500
            reflectionsLevel = -1000
            reflectionsDelay = 50
            reverbLevel = -500
            reverbDelay = 100
            diffusion = 1000
            density = 1000
        }
    }

    fun startProcessing() {
        if (audioRecord == null || audioTrack == null) {
            Log.e(TAG, "Cannot start: not initialized")
            return
        }
        isProcessing = true
        audioRecord?.startRecording()
        audioTrack?.play()

        processingJob = scope.launch {
            val bufferSize = 4096
            val inputBuffer = FloatArray(bufferSize)

            while (isProcessing) {
                val read = audioRecord?.read(inputBuffer, 0, bufferSize, AudioRecord.READ_BLOCKING) ?: 0

                if (read > 0) {
                    val processed = when (currentMode) {
                        AudioMode.STEREO -> applyEqualizer(inputBuffer, read)
                        AudioMode.SURROUND_51 -> applyUpmixSimulation(inputBuffer, read, height = false)
                        AudioMode.DOLBY_ATMOS_512 -> applyUpmixSimulation(inputBuffer, read, height = true)
                        AudioMode.SPATIAL_3D -> applySpatial3D(inputBuffer, read)
                    }
                    audioTrack?.write(processed, 0, processed.size, AudioTrack.WRITE_BLOCKING)
                }
            }
        }
    }

    private fun applyEqualizer(input: FloatArray, len: Int): FloatArray {
        val output = FloatArray(len)
        for (i in 0 until len) {
            output[i] = input[i].coerceIn(-1f, 1f)
        }
        return output
    }

    /**
     * Stereo-out upmix simulation: applies width/HRTF-style processing while
     * keeping the actual AudioTrack as 2-channel stereo (matches the buffer
     * we actually opened — previous version wrote 6/8-channel float arrays
     * into a stereo AudioTrack, which would underrun/garble).
     */
    private fun applyUpmixSimulation(input: FloatArray, len: Int, height: Boolean): FloatArray {
        val output = FloatArray(len)
        val delaySamples = (0.0007 * sampleRate).toInt().coerceAtLeast(1)

        for (i in 0 until len step 2) {
            if (i + 1 >= len) break
            val left = input[i]
            val right = input[i + 1]

            val delayedLeftIdx = i - delaySamples
            val delayedLeft = if (delayedLeftIdx >= 0) input[delayedLeftIdx] else 0f

            val width = if (height) 1.25f else 1.1f
            val center = (left + right) * 0.5f

            var outLeft = (left * width + delayedLeft * 0.15f - center * 0.1f)
            var outRight = (right * width - center * 0.1f)

            if (height) {
                // subtle high-shelf style emphasis to fake "elevation" cue
                outLeft *= 1.05f
                outRight *= 1.05f
            }

            output[i] = outLeft.coerceIn(-1f, 1f)
            output[i + 1] = outRight.coerceIn(-1f, 1f)
        }
        return output
    }

    private fun applySpatial3D(input: FloatArray, len: Int): FloatArray {
        val output = FloatArray(len)
        for (i in 0 until len step 2) {
            if (i + 1 >= len) break
            val left = input[i]
            val right = input[i + 1]

            val w = (left + right) * 0.5f
            val y = (left - right) * 0.5f

            output[i] = (w + y * 0.7f).coerceIn(-1f, 1f)
            output[i + 1] = (w - y * 0.7f).coerceIn(-1f, 1f)
        }
        return output
    }

    fun setEqualizerBand(band: Int, level: Float) {
        equalizerBands[band] = level.coerceIn(-15f, 15f)
        val hwBandCount = equalizer?.numberOfBands?.toInt() ?: 0
        // Devices commonly expose fewer hardware EQ bands (often 5-6) than
        // our 10-band UI. Map our band index down proportionally instead of
        // calling setBandLevel() with an out-of-range index, which throws.
        if (hwBandCount in 1..equalizerBands.size) {
            val hwBand = (band * hwBandCount / equalizerBands.size).coerceIn(0, hwBandCount - 1)
            try {
                equalizer?.setBandLevel(hwBand.toShort(), (level * 100).toInt().toShort())
            } catch (e: Exception) {
                Log.e(TAG, "setBandLevel failed: ${e.message}")
            }
        } else if (hwBandCount > 0) {
            try {
                equalizer?.setBandLevel(band.toShort(), (level * 100).toInt().toShort())
            } catch (e: Exception) {
                Log.e(TAG, "setBandLevel failed: ${e.message}")
            }
        }
    }

    /** Applies a full preset (e.g. from EqualizerPresets) across all bands at once. */
    fun applyPreset(bands: FloatArray) {
        for (i in bands.indices) {
            if (i < equalizerBands.size) {
                setEqualizerBand(i, bands[i])
            }
        }
    }

    fun setBassBoost(strength: Int) {
        bassBoost?.setStrength(strength.coerceIn(0, 1000).toShort())
    }

    fun setAudioMode(mode: AudioMode) {
        currentMode = mode
        when (mode) {
            AudioMode.STEREO -> {
                virtualizer?.enabled = false
                reverb?.enabled = false
            }
            AudioMode.SURROUND_51 -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(1000)
                reverb?.enabled = true
            }
            AudioMode.DOLBY_ATMOS_512 -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(1000)
                reverb?.enabled = true
            }
            AudioMode.SPATIAL_3D -> {
                virtualizer?.enabled = true
                reverb?.enabled = true
            }
        }
    }

    fun stopProcessing() {
        isProcessing = false
        processingJob?.cancel()
        audioRecord?.stop()
        audioTrack?.stop()
    }

    fun release() {
        stopProcessing()
        equalizer?.release()
        virtualizer?.release()
        bassBoost?.release()
        reverb?.release()
        audioRecord?.release()
        audioTrack?.release()
    }
}

// Preset EQ Profiles (10 bands: 31Hz, 62Hz, 125Hz, 250Hz, 500Hz, 1kHz, 2kHz, 4kHz, 8kHz, 16kHz)
object EQPresets {
    val FLAT = FloatArray(10) { 0f }
    val BASS_BOOST = floatArrayOf(8f, 6f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f)
    val VOCAL_BOOST = floatArrayOf(-2f, -2f, 0f, 3f, 6f, 4f, 2f, 0f, 0f, 0f)
    val TREBLE_BOOST = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 2f, 4f, 6f, 8f)
    val MOVIE = floatArrayOf(4f, 3f, 2f, 1f, 0f, 1f, 3f, 5f, 4f, 3f)
    val MUSIC = floatArrayOf(3f, 2f, 1f, 0f, 1f, 2f, 3f, 4f, 3f, 2f)
    val GAMING = floatArrayOf(5f, 4f, 2f, 0f, 2f, 4f, 5f, 3f, 2f, 1f)
    val POP = floatArrayOf(-1f, 1f, 3f, 4f, 2f, -1f, -1f, 1f, 2f, 2f)
    val CLASSICAL = floatArrayOf(4f, 3f, 2f, 1f, -1f, -1f, 0f, 2f, 3f, 4f)
    val JAZZ = floatArrayOf(3f, 2f, 1f, 2f, -1f, -1f, 0f, 1f, 2f, 3f)

    /** All built-in presets, name -> band levels, in display order. */
    val ALL: LinkedHashMap<String, FloatArray> = linkedMapOf(
        "Flat" to FLAT,
        "Bass Boost" to BASS_BOOST,
        "Vocal Boost" to VOCAL_BOOST,
        "Treble Boost" to TREBLE_BOOST,
        "Movie" to MOVIE,
        "Music" to MUSIC,
        "Gaming" to GAMING,
        "Pop" to POP,
        "Classical" to CLASSICAL,
        "Jazz" to JAZZ
    )
}
