package com.ultraboost.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * NOTE: Android does NOT allow silently resuming MediaProjection (screen
 * capture) after boot — that permission is single-use and requires a fresh
 * user consent dialog each time for privacy/security reasons. There is no
 * legitimate way around this. So this receiver intentionally does NOT
 * auto-start ScreenCaptureService/AudioEnhancerService.
 *
 * What it CAN legitimately do: show a notification prompting the user to
 * reopen the app and re-grant capture, if they had it active before reboot.
 * Left as a no-op stub here — wire up a notification call if you want that.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Intentionally no auto-start of capture services. See class doc above.
        }
    }
}
