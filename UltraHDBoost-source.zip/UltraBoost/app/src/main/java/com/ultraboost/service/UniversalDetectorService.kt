package com.ultraboost.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.ultraboost.overlay.FloatingWindowService

/**
 * Universal "what app is in front" detector. We deliberately do NOT keep a
 * hardcoded list of "supported video apps" — the goal is universal coverage,
 * so we just track the foreground package and broadcast it. The floating
 * overlay decides what to do with that info (e.g. only auto-show itself for
 * apps the user has enabled in settings — that filtering logic is a product
 * decision, not implemented here to avoid silently watching every app).
 */
class UniversalDetectorService : AccessibilityService() {

    companion object {
        const val ACTION_FOREGROUND_APP_CHANGED = "com.ultraboost.FOREGROUND_APP_CHANGED"
        const val EXTRA_PACKAGE_NAME = "extra_package_name"

        @Volatile
        var currentForegroundPackage: String? = null
            private set
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString() ?: return
            if (pkg == packageName) return // ignore our own app/overlay

            if (pkg != currentForegroundPackage) {
                currentForegroundPackage = pkg
                notifyForegroundAppChanged(pkg)
            }
        }
    }

    private fun notifyForegroundAppChanged(pkg: String) {
        val intent = Intent(ACTION_FOREGROUND_APP_CHANGED).apply {
            putExtra(EXTRA_PACKAGE_NAME, pkg)
            setPackage(packageName)
        }
        sendBroadcast(intent)

        // Let the floating window service know it can update/show itself for this app.
        val serviceIntent = Intent(this, FloatingWindowService::class.java).apply {
            putExtra(EXTRA_PACKAGE_NAME, pkg)
        }
        try {
            startService(serviceIntent)
        } catch (e: Exception) {
            // Service may not be running yet (overlay permission not granted) — ignore.
        }
    }

    override fun onInterrupt() {
        // Required override, nothing to clean up.
    }
}
