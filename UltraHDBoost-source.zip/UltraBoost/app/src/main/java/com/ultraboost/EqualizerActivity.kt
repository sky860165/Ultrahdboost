package com.ultraboost

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultraboost.audio.EqualizerPresets
import com.ultraboost.service.AudioEnhancerService
import com.ultraboost.ui.theme.UltraBoostTheme

/**
 * Equalizer & Sound Effects screen: 10 built-in presets + a 10-band slider
 * UI that live-updates AudioEnhancerService.activeAudioEnhancer (if the
 * enhancer is currently running) and a "Custom" preset that can be saved
 * and reloaded across app restarts via EqualizerPresets.saveCustom().
 */
class EqualizerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UltraBoostTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    EqualizerScreen(onBack = { finish() })
                }
            }
        }
    }
}

@Composable
fun EqualizerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val presets = remember { EqualizerPresets.builtIn }
    var customPreset by remember { mutableStateOf(EqualizerPresets.loadCustom(context)) }
    var selectedPresetName by remember { mutableStateOf("Flat") }
    var bands by remember { mutableStateOf(FloatArray(EqualizerPresets.BAND_COUNT) { 0f }) }

    fun applyToLiveEnhancer(newBands: FloatArray) {
        // No-op if the enhancer service isn't currently running — bands are
        // still saved/selected and will apply next time it starts, since
        // STEREO mode etc. re-reads AppSettings/whatever the service wires.
        AudioEnhancerService.activeAudioEnhancer?.applyPreset(newBands)
    }

    fun selectPreset(preset: com.ultraboost.audio.EqPreset) {
        selectedPresetName = preset.name
        bands = preset.bands.copyOf()
        applyToLiveEnhancer(bands)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F0F23), Color(0xFF1A1A3E), Color(0xFF0F0F23))
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) {
                Text("\u2190 Back", color = Color(0xFF00D4FF))
            }
        }

        Text(
            text = "\uD83C\uDF9A\uFE0F Equalizer & Sound Effects",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00D4FF),
            modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
        )

        Text(
            text = "Presets",
            fontSize = 14.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(presets + customPreset) { preset ->
                PresetChip(
                    name = preset.name,
                    selected = selectedPresetName == preset.name,
                    onClick = { selectPreset(preset) }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E3F))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 20.dp, horizontal = 8.dp)
                    .height(260.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                EqualizerPresets.bandLabels.forEachIndexed { index, label ->
                    BandSlider(
                        label = label,
                        value = bands.getOrElse(index) { 0f },
                        onValueChange = { newVal ->
                            val updated = bands.copyOf()
                            updated[index] = newVal
                            bands = updated
                            selectedPresetName = "Custom"
                            applyToLiveEnhancer(updated)
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                EqualizerPresets.saveCustom(context, bands)
                customPreset = EqualizerPresets.loadCustom(context)
                selectedPresetName = "Custom"
                Toast.makeText(context, "Custom preset saved", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D4FF))
        ) {
            Text("\uD83D\uDCBE Save as Custom Preset", color = Color.Black, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(
            onClick = {
                bands = FloatArray(EqualizerPresets.BAND_COUNT) { 0f }
                selectedPresetName = "Flat"
                applyToLiveEnhancer(bands)
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Gray)
        ) {
            Text("Reset to Flat")
        }

        if (AudioEnhancerService.activeAudioEnhancer == null) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "\u26A0\uFE0F Ultra HD Boost isn't running right now — changes are saved and will apply next time you activate it.",
                fontSize = 12.sp,
                color = Color(0xFFFFA500)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun PresetChip(name: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) Color(0xFF00D4FF) else Color(0xFF2A2A5A))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(
            text = name,
            color = if (selected) Color.Black else Color.White,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
fun BandSlider(label: String, value: Float, onValueChange: (Float) -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxHeight()
    ) {
        Text(
            text = "%+.0f".format(value),
            fontSize = 10.sp,
            color = Color(0xFF00D4FF)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = -15f..15f,
            modifier = Modifier
                .weight(1f)
                .width(40.dp)
                .rotate(-90f),
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF00D4FF),
                activeTrackColor = Color(0xFF00D4FF),
                inactiveTrackColor = Color(0xFF2A2A5A)
            )
        )
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color.Gray
        )
    }
}
