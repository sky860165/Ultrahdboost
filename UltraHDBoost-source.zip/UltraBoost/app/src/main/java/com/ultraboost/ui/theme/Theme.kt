package com.ultraboost.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = UltraBoostCyan,
    secondary = UltraBoostGold,
    background = UltraBoostBgDark,
    surface = UltraBoostCard,
    error = UltraBoostError
)

private val LightColors = lightColorScheme(
    primary = UltraBoostCyan,
    secondary = UltraBoostGold,
    background = UltraBoostBgMid,
    surface = UltraBoostCard,
    error = UltraBoostError
)

@Composable
fun UltraBoostTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
